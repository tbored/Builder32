var canvas = document.getElementById('canvas');
var selectedBlockType = 'block_textures/grass.png';

function placeBlock(x, y) {
    canvas.innerHTML += '<img src="' + selectedBlockType + '" id="x' + x + 'y' + y + '" onclick="editBlock(' + x + ',' + y + ')" class="block" style="top: ' + y*20 + 'px; left: ' + x*20 + 'px;">';
};

function editBlock(x, y) {
  document.getElementById('x' + x + 'y' + y).src = selectedBlockType;
};

for (let i = 0; i < 32; i++) {
  selectedBlockType = 'block_textures/air.png'
  placeBlock(i, 0);
  placeBlock(i, 1);
  placeBlock(i, 2);
  placeBlock(i, 3);
  placeBlock(i, 4);
  placeBlock(i, 5);
  placeBlock(i, 6);
  placeBlock(i, 7);
  placeBlock(i, 8);
  placeBlock(i, 9);
  placeBlock(i, 10);
  placeBlock(i, 11);
  placeBlock(i, 12);
  placeBlock(i, 13);
  placeBlock(i, 14);
  placeBlock(i, 15);
  placeBlock(i, 16);
  placeBlock(i, 17);
  placeBlock(i, 18);
  placeBlock(i, 19);
  placeBlock(i, 20);
  placeBlock(i, 21);
  placeBlock(i, 22);
  placeBlock(i, 23);
  placeBlock(i, 24);
  placeBlock(i, 25);
  placeBlock(i, 26);
  selectedBlockType = 'block_textures/grass.png'
  placeBlock(i, 27);
  selectedBlockType = 'block_textures/dirt.png'
  placeBlock(i, 28);
  placeBlock(i, 29);
  placeBlock(i, 30);
  placeBlock(i, 31);
};

selectedBlockType = 'block_textures/wood.png';

